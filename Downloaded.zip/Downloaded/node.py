from keyauth import api
import hashlib
import os
import sys
import time
import threading
import subprocess
import requests
import zipfile
import dearpygui.dearpygui as dpg

# Function to calculate the checksum of the current script
def getchecksum():
    md5_hash = hashlib.md5()
    with open(__file__, "rb") as file:  # Use __file__ for the current file
        md5_hash.update(file.read())
    return md5_hash.hexdigest()

# Initialize KeyAuth
keyauthapp = api(
    name="Divide",  # Application Name
    ownerid="47cnKK0I84",  # Owner ID
    secret="1d1927893c760ccb532d59930525689cd2fcdf13d96ff87d568",  # Application Secret
    version="1.0",  # Application Version
    hash_to_check=getchecksum()
)

# Function to handle login with only a license key
def on_login():
    license_key = dpg.get_value("license_input")
    try:
        current_checksum = getchecksum()
        print("Current Checksum:", current_checksum)  # Debug: Print the current checksum
        response = keyauthapp.license(license_key)  # Attempt to login using the license key
        print("Response:", response)  # Debug: Print the response
        
        if response['success']:
            show_user_data()
            dpg.set_value("status_output", "Login successful! Loading files...")

            # Start a separate thread to handle the download and launching
            threading.Thread(target=download_and_launch).start()
        else:
            dpg.set_value("status_output", f"Login failed: {response['message']}")

    except Exception as e:
        dpg.set_value("status_output", f"Login failed: {str(e)}")
        print("Error:", e)  # Debug: Print the error

# Function to display user data
def show_user_data():
    user_data = f"Username: {keyauthapp.user_data.username}\n" \
                f"IP address: {keyauthapp.user_data.ip}\n" \
                f"Hardware ID: {keyauthapp.user_data.hwid}\n"
    dpg.set_value("user_data_output", user_data)

# Function to download a zip file
def download_file(url, dest_path):
    print(f"Downloading from {url}...")
    response = requests.get(url)
    response.raise_for_status()  # Raise an error for bad responses
    with open(dest_path, 'wb') as file:
        file.write(response.content)
    print(f"Downloaded to {dest_path}")

# Function to extract a ZIP file to a specified directory
def extract_zip(zip_path, extract_to):
    print(f"Extracting {zip_path} to {extract_to}...")
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(extract_to)
    print(f"Extracted to {extract_to}")

# Function to launch the main.py script after downloading and extracting
def download_and_launch():
    url = "https://github.com/Pearlism/cfg/raw/refs/heads/main/node.zip"  # Replace with your zip file URL
    zip_file_name = "help.zip"
    extract_dir = "help"

    # Ensure the extract directory exists
    os.makedirs(extract_dir, exist_ok=True)

    try:
        # Download the zip file
        download_file(url, zip_file_name)

        # Extract the zip file
        extract_zip(zip_file_name, extract_dir)

        # Launch the main.py script
        main_script_path = os.path.join(extract_dir, "main.py")  # Path to main.py in the extracted folder
        if os.path.exists(main_script_path):
            subprocess.run(["python", main_script_path])  # Specify the Python interpreter
            dpg.set_value("status_output", "Spectre Divide Cheat is now running.")
        else:
            dpg.set_value("status_output", f"main.py not found in {extract_dir}")

    except Exception as e:
        dpg.set_value("status_output", f"Failed to launch: {str(e)}")
        print("Error launching the script:", e)  # Debug: Print the error

# Main function to set up DearPyGui
def main():
    dpg.create_context()

    # Create main window
    with dpg.window(label="Login", width=400, height=300):
        dpg.add_text("419 Login")
        dpg.add_text("License Key")
        dpg.add_input_text(tag="license_input", width=300)
        
        dpg.add_button(label="Login", callback=on_login)
        
        dpg.add_separator()
        
        dpg.add_text("Status:")
        dpg.add_input_text(tag="status_output", multiline=True, readonly=True, height=50)

        dpg.add_text("User Data:")
        dpg.add_input_text(tag="user_data_output", multiline=True, readonly=True, height=100)

    # Show the DearPyGui window
    dpg.create_viewport(title="419 Login", width=400, height=300)
    dpg.setup_dearpygui()
    dpg.show_viewport()
    dpg.start_dearpygui()
    dpg.destroy_context()

# Check if the script is run directly
if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"An error occurred: {e}")
        input("Press Enter to exit...")  # Keep the window open to read the error message
